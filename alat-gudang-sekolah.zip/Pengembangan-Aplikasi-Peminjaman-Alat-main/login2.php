<?php
session_start();
include 'config.php';
include 'db.php';

trace_event("OPEN PAGE login.php");

// Jika sudah login, langsung dialihkan ke halaman utama barang
if (isset($_SESSION['username'])) {
    header("Location: index_barang.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Masuk - E-Gudang SMKN 1 Sanden</title>
    <link rel="stylesheet" type="text/css" href="tambahan/bootstrap-4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="tambahan/font-awesome/css/font-awesome.css">
    
    <style>
        :root {
            --primary-color: #1e3c72;
            --secondary-color: #2a5298;
            --bg-color: #607aa1;
        }

        body {
            background-color: var(--bg-color);
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-wrapper {
            width: 100%;
            max-width: 900px;
            height: 550px;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
            display: flex;
            overflow: hidden;
            margin: 15px;
        }

        /* Sisi Kiri: Visual & Branding */
        .login-side-visual {
            flex: 1;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px;
            text-align: center;
            position: relative;
        }

        .brand-logo {
            width: 110px;
            height: auto;
            margin-bottom: 20px;
            filter: drop-shadow(0px 8px 15px rgba(0, 0, 0, 0.3));
            animation: float 4s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }

        .brand-title {
            font-size: 26px;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .brand-subtitle {
            font-size: 14px;
            opacity: 0.8;
            font-weight: 400;
        }

        /* Sisi Kanan: Form Input */
        .login-side-form {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: #ffffff;
        }

        .form-title {
            color: #2c3e50;
            font-weight: 700;
            font-size: 22px;
            margin-bottom: 25px;
        }

        /* Nav Tabs Custom */
        .nav-tabs-login {
            border-bottom: 2px solid #f1f2f6;
            margin-bottom: 25px;
        }

        .nav-tabs-login .nav-link {
            border: none;
            color: #8c96a0;
            font-weight: 600;
            font-size: 15px;
            padding: 10px 0;
            margin-right: 30px;
            position: relative;
            background: transparent;
        }

        .nav-tabs-login .nav-link.active {
            color: var(--primary-color) !important;
            background: transparent !important;
        }

        .nav-tabs-login .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 3px;
        }

        .form-group label {
            font-weight: 600;
            color: #546e7a;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .input-box {
            position: relative;
        }

        .input-box i {
            position: absolute;
            left: 15px;
            top: 14px;
            color: #90a4ae;
            font-size: 16px;
            z-index: 5;
        }

        /* KODE FIX: Mengganti nama class agar tidak bentrok dengan Bootstrap */
        .form-input-gudang {
            padding-left: 45px !important;
            height: 46px;
            border-radius: 8px;
            border: 1.5px solid #e2e8f0;
            background-color: #f8fafc;
            transition: all 0.3s ease;
            display: block;
            width: 100%;
        }

        .form-input-gudang:focus {
            border-color: var(--secondary-color);
            background-color: #ffffff;
            box-shadow: 0 0 0 0.2rem rgba(42, 82, 152, 0.1);
            outline: none;
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            color: white;
            height: 46px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            margin-top: 20px;
            box-shadow: 0 4px 12px rgba(30, 60, 114, 0.2);
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 60, 114, 0.35);
            color: #fff;
        }

        .register-hint {
            text-align: center;
            margin-top: 25px;
            font-size: 13px;
            color: #78909c;
        }

        .register-hint a {
            color: var(--secondary-color);
            font-weight: 700;
            text-decoration: none;
        }

        /* Responsif untuk Layar HP */
        @media (max-width: 768px) {
            .login-wrapper {
                flex-direction: column;
                height: auto;
            }
            .login-side-visual {
                padding: 30px 20px;
            }
            .brand-logo {
                width: 80px;
            }
            .brand-title {
                font-size: 20px;
            }
            .login-side-form {
                padding: 30px 20px;
            }
        }
    </style>
</head>

<body>

    <div class="login-wrapper">
        
        <div class="login-side-visual">
            <img src="assets/img/smk.jpg" alt="Logo SMKN 1 Sanden" class="brand-logo">
            <h1 class="brand-title">E-GUDANG</h1>
            <p class="brand-subtitle">Sistem Informasi Peminjaman Alat<br>SMKN 1 Sanden Bantul</p>
        </div>

        <div class="login-side-form">
            <h2 class="form-title">Selamat Datang 👋</h2>

            <ul class="nav nav-tabs nav-tabs-login" id="loginTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="siswa-tab" data-toggle="tab" href="#siswa" role="tab">
                        <i class="fa fa-user mr-1"></i> Siswa / Peminjam
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab">
                        <i class="fa fa-user-secret mr-1"></i> Petugas / Admin
                    </a>
                </li>
            </ul>

            <div class="tab-content" id="loginTabContent">
                <div class="tab-pane fade show active" id="siswa" role="tabpanel">
                    <form action="proses-login.php" method="POST">
                        <input type="hidden" name="role" value="peminjam">
                        
                        <div class="form-group">
                            <label>Username / NISN</label>
                            <div class="input-box">
                                <i class="fa fa-user"></i>
                                <input type="text" name="username" class="form-input-gudang" placeholder="Masukkan username" required autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Password</label>
                            <div class="input-box">
                                <i class="fa fa-lock"></i>
                                <input type="password" name="password" class="form-input-gudang" placeholder="Masukkan password" required>
                            </div>
                        </div>

                        <button type="submit" name="login" class="btn btn-primary btn-block btn-submit">
                            <i class="fa fa-sign-in mr-1"></i> Masuk ke Sistem
                        </button>
                    </form>
                </div>

                <div class="tab-pane fade" id="admin" role="tabpanel">
                    <form action="proses-login.php" method="POST">
                        <input type="hidden" name="role" value="staff">

                        <div class="form-group">
                            <label>Username Petugas</label>
                            <div class="input-box">
                                <i class="fa fa-user-circle"></i>
                                <input type="text" name="username" class="form-input-gudang" placeholder="Username khusus petugas" required autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Password</label>
                            <div class="input-box">
                                <i class="fa fa-lock"></i>
                                <input type="password" name="password" class="form-input-gudang" placeholder="Masukkan password" required>
                            </div>
                        </div>

                        <button type="submit" name="login" class="btn btn-primary btn-block btn-submit">
                            <i class="fa fa-lock mr-1"></i> Verifikasi Petugas
                        </button>
                    </form>
                </div>
            </div>

            <div class="register-hint">
                Belum terdaftar? <a href="register.php">Buat Akun Baru</a>
            </div>
        </div>

    </div>

    <script type="text/javascript" src="tambahan/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="tambahan/bootstrap-4.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>