<?php
session_start();
include 'config.php';
include 'db.php';

trace_event("OPEN PAGE login.php");

// Jika sudah login, langsung dialihkan ke halaman utama barang
if (isset($_SESSION['username'])) {
    header("Location: index_barang.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login - Sistem Peminjaman Alat Gudang Sekolah</title>
    <link rel="stylesheet" type="text/css" href="tambahan/bootstrap-4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="tambahan/font-awesome/css/font-awesome.css">
    
    <style>
        body {
            background-color: #607aa1; /* Warna disamakan dengan index_barang */
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            width: 100%;
            max-width: 450px;
            padding: 15px;
        }

        .login-card {
            background: #ffffff;
            border: none;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .login-header {
            background: linear-gradient(135deg, #ffffff 0%, #2a5298 100%);
            color: #ffffff;
            padding: 35px 20px;
            text-align: center;
        }

        .login-header i {
            font-size: 50px;
            margin-bottom: 10px;
            color: #f1c40f; /* Efek warna emas untuk ikon gudang */
        }

        .login-header h2 {
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }

        .login-header p {
            font-size: 13px;
            opacity: 0.8;
            margin: 5px 0 0 0;
        }

        .login-body {
            padding: 30px;
        }

        /* Nav Tabs untuk membedakan Hak Akses */
        .nav-pills-custom {
            margin-bottom: 25px;
            background: #f4f6f9;
            padding: 5px;
            border-radius: 30px;
        }

        .nav-pills-custom .nav-link {
            border-radius: 30px;
            color: #607aa1;
            font-weight: 600;
            font-size: 14px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .nav-pills-custom .nav-link.active {
            background-color: #1e3c72;
            color: #ffffff;
            box-shadow: 0 4px 10px rgba(30, 60, 114, 0.2);
        }

        .form-group label {
            font-weight: 600;
            color: #34495e;
            font-size: 14px;
        }

        .input-group-custom {
            position: relative;
        }

        .input-group-custom i {
            position: absolute;
            left: 15px;
            top: 15px;
            color: #a0aab2;
            z-index: 10;
        }

        .form-control-custom {
            padding-left: 45px !important;
            height: 48px;
            border-radius: 10px;
            border: 1.5px solid #eaeaea;
            background-color: #fcfcfc;
            transition: all 0.3s ease;
        }

        .form-control-custom:focus {
            border-color: #2a5298;
            background-color: #ffffff;
            box-shadow: 0 0 0 0.2rem rgba(42, 82, 152, 0.1);
        }

        .btn-login {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            color: white;
            height: 48px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 60, 114, 0.4);
            color: #fff;
        }

        .login-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #ffffff;
        }

        .login-footer a {
            color: #f1c40f;
            font-weight: bold;
            text-decoration: none;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
             <img src="assets/img/smk.png" alt="Logo SMKN 1 Sanden" class="login-logo">
             <h2>E-GUDANG SEKOLAH</h2>
             <p>SMKN 1 Sanden Bantul</p>
            </div>

            <div class="login-body">
                <ul class="nav nav-pills nav-fill nav-pills-custom" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="tab-peminjam" data-toggle="pill" href="#login-peminjam" role="tab" aria-selected="true">
                            <i class="fa fa-user"></i> Siswa / Peminjam
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-admin" data-toggle="pill" href="#login-admin" role="tab" aria-selected="false">
                            <i class="fa fa-user-secret"></i> Petugas / Admin
                        </a>
                    </li>
                </ul>

                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="login-peminjam" role="tabpanel">
                        <form action="proses-login.php" method="POST">
                            <input type="hidden" name="role" value="peminjam">
                            
                            <div class="form-group">
                                <label>Username / NISN</label>
                                <div class="input-group-custom">
                                    <i class="fa fa-user"></i>
                                    <input type="text" name="username" class="form-control form-control-custom" placeholder="Masukkan username Anda" required autocomplete="off">
                                </div>
                            </div>
                            
                            <div class="form-group mb-4">
                                <label>Password</label>
                                <div class="input-group-custom">
                                    <i class="fa fa-lock"></i>
                                    <input type="password" name="password" class="form-control form-control-custom" placeholder="Masukkan password Anda" required>
                                </div>
                            </div>

                            <button type="submit" name="login" class="btn btn-primary btn-block btn-login">
                                <i class="fa fa-sign-in"></i> Masuk Sistem
                            </button>
                        </form>
                    </div>

                    <div class="tab-pane fade" id="login-admin" role="tabpanel">
                        <form action="proses-login.php" method="POST">
                            <input type="hidden" name="role" value="staff">

                            <div class="form-group">
                                <label>Username Petugas</label>
                                <div class="input-group-custom">
                                    <i class="fa fa-user-circle"></i>
                                    <input type="text" name="username" class="form-control form-control-custom" placeholder="Username khusus petugas" required autocomplete="off">
                                </div>
                            </div>
                            
                            <div class="form-group mb-4">
                                <label>Password</label>
                                <div class="input-group-custom">
                                    <i class="fa fa-lock"></i>
                                    <input type="password" name="password" class="form-control form-control-custom" placeholder="Masukkan password" required>
                                </div>
                            </div>

                            <button type="submit" name="login" class="btn btn-primary btn-block btn-login">
                                <i class="fa fa-lock"></i> Login Petugas
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="login-footer">
            Belum punya akun? <a href="register.php">Daftar Akun Sekarang</a><br>
            <small class="text-light opacity-50 d-block mt-3">&copy; <?php echo date("Y"); ?> Gudang Sekolah. All rights reserved.</small>
        </div>
    </div>

    <script type="text/javascript" src="tambahan/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="tambahan/bootstrap-4.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>